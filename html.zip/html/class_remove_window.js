var class_remove_window =
[
    [ "RemoveWindow", "class_remove_window.html#a3defae9a4d9ea8de7bc6f6191c659136", null ],
    [ "~RemoveWindow", "class_remove_window.html#a91e3d15bdc59df10d3fe7055b44867f3", null ]
];