var globals_func =
[
    [ "i", "globals_func.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "s", "globals_func_s.html", null ]
];