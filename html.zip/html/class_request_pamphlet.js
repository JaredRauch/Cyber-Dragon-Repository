var class_request_pamphlet =
[
    [ "RequestPamphlet", "class_request_pamphlet.html#a650e986f8b4affccaa9b9b2345b93245", null ],
    [ "~RequestPamphlet", "class_request_pamphlet.html#ae609be843bb0d6ca88f58289cbc3544d", null ]
];