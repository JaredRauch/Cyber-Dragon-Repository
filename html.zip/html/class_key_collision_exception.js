var class_key_collision_exception =
[
    [ "KeyCollisionException", "class_key_collision_exception.html#a00c189b2e86384fa652767b82dc0181f", null ],
    [ "~KeyCollisionException", "class_key_collision_exception.html#a19180e949fbbae6599e81d2b21fb34f2", null ],
    [ "what", "class_key_collision_exception.html#a89e57658fbbe3273133cc18b8b59630f", null ]
];