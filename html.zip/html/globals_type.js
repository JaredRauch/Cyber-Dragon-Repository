var globals_type =
[
    [ "a", "globals_type.html", null ],
    [ "b", "globals_type_b.html", null ],
    [ "c", "globals_type_c.html", null ],
    [ "d", "globals_type_d.html", null ],
    [ "e", "globals_type_e.html", null ],
    [ "f", "globals_type_f.html", null ],
    [ "h", "globals_type_h.html", null ],
    [ "i", "globals_type_i.html", null ],
    [ "k", "globals_type_k.html", null ],
    [ "l", "globals_type_l.html", null ],
    [ "m", "globals_type_m.html", null ],
    [ "n", "globals_type_n.html", null ],
    [ "o", "globals_type_o.html", null ],
    [ "p", "globals_type_p.html", null ],
    [ "r", "globals_type_r.html", null ],
    [ "s", "globals_type_s.html", null ],
    [ "t", "globals_type_t.html", null ],
    [ "u", "globals_type_u.html", null ],
    [ "v", "globals_type_v.html", null ],
    [ "w", "globals_type_w.html", null ],
    [ "y", "globals_type_y.html", null ]
];