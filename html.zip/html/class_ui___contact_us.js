var class_ui___contact_us =
[
    [ "retranslateUi", "class_ui___contact_us.html#a450b14784e49048a12740d6ba6dd0ba8", null ],
    [ "setupUi", "class_ui___contact_us.html#abe9c8db1809059fa8aab6db9c1e466b2", null ],
    [ "label", "class_ui___contact_us.html#ab09ff100f1fb9ffb3ff73988830d5055", null ],
    [ "textBrowser", "class_ui___contact_us.html#acbf823ef403d243570c9ca5e0acab967", null ],
    [ "verticalLayout", "class_ui___contact_us.html#a1de6fae4ec306430246d04a512d9377c", null ]
];