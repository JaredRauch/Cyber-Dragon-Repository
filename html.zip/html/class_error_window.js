var class_error_window =
[
    [ "ErrorWindow", "class_error_window.html#a734664c56c8a99a674e047c64b917c34", null ],
    [ "~ErrorWindow", "class_error_window.html#ad1c26658b7ae64e2dc4a60567ccc767f", null ]
];