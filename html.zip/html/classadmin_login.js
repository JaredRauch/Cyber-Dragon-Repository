var classadmin_login =
[
    [ "adminLogin", "classadmin_login.html#abdac896ba4bdaac520407b2221148779", null ],
    [ "~adminLogin", "classadmin_login.html#a07df3084a4af479f26e556b2216818f8", null ]
];