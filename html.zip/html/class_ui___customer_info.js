var class_ui___customer_info =
[
    [ "retranslateUi", "class_ui___customer_info.html#ac130a8e79a0705e080e496ea7c4a0736", null ],
    [ "setupUi", "class_ui___customer_info.html#af52bd27d42ac6d665bb3be925b710faf", null ],
    [ "addressLabel", "class_ui___customer_info.html#a17c6336ccdd02a9d87ce8b9a98b4fac8", null ],
    [ "centralwidget", "class_ui___customer_info.html#ad9b62e746cddbc7ea4a8a620f7584d32", null ],
    [ "interestLabel", "class_ui___customer_info.html#aaa4abaf2dce26f4755f9bdd60248641c", null ],
    [ "isKeyLabel", "class_ui___customer_info.html#a42b5e32170e80cbeaf7cc95a2f072745", null ],
    [ "menubar", "class_ui___customer_info.html#af7199341712f4e3bc28ed1e7bf3a8831", null ],
    [ "nameLabel", "class_ui___customer_info.html#a1ff066910ffb0af99c821ec33ce76bec", null ],
    [ "scrollArea", "class_ui___customer_info.html#a0da76660201ec59878f9692eecdd7e5b", null ],
    [ "scrollAreaWidgetContents", "class_ui___customer_info.html#aba243d1e8ee2a617ed7838680847b315", null ],
    [ "statusbar", "class_ui___customer_info.html#a2d528610f69135a574f54e1d3e2aae96", null ],
    [ "tableWidget", "class_ui___customer_info.html#a898f1b7913ccccc6ea35504952f75e27", null ]
];