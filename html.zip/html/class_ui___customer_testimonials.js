var class_ui___customer_testimonials =
[
    [ "retranslateUi", "class_ui___customer_testimonials.html#a5a2c92b8f5d82dccc5c782408cf2548e", null ],
    [ "setupUi", "class_ui___customer_testimonials.html#a4229786574a932b55ecd38d2e51219cb", null ],
    [ "label", "class_ui___customer_testimonials.html#a83b1a26e5f4c76a3cc0f811d136ea931", null ],
    [ "label_2", "class_ui___customer_testimonials.html#affcb91cf8e043cd2697839e5cee025c9", null ],
    [ "label_3", "class_ui___customer_testimonials.html#ac912356113e1038e1298a0ec172fdc55", null ],
    [ "lineEdit", "class_ui___customer_testimonials.html#a9bb1319a11241befa42d2755344a244b", null ],
    [ "pushButton", "class_ui___customer_testimonials.html#acaeb8c102a56d3e76ba127cc594e3bd2", null ],
    [ "tableWidget", "class_ui___customer_testimonials.html#a708b3bb873fdf37d5044a31f9d528ca2", null ],
    [ "textEdit", "class_ui___customer_testimonials.html#ac3c59bbde2b5eaf100e2cc8d436834a6", null ],
    [ "verticalLayout", "class_ui___customer_testimonials.html#a2b6b83087b59c354c639659beb44636b", null ]
];