var class_ui___dialog =
[
    [ "retranslateUi", "class_ui___dialog.html#afa0ccb6f716ca6178260522a193c250e", null ],
    [ "setupUi", "class_ui___dialog.html#a4f6a478c3ecdafabffb17b39cb26444a", null ]
];