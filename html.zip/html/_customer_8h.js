var _customer_8h =
[
    [ "Customer", "class_customer.html", "class_customer" ],
    [ "Interest", "_customer_8h.html#a406b0c0f39662fd6ef695c1d181d81da", [
      [ "NOT_INTERESTED", "_customer_8h.html#a406b0c0f39662fd6ef695c1d181d81daab2c58a77255346baa64f96f3fb518707", null ],
      [ "SOMEWHAT_INTERESTED", "_customer_8h.html#a406b0c0f39662fd6ef695c1d181d81daa3c15757d4bc456c639cc215f2efe6f3c", null ],
      [ "VERY_INTERESTED", "_customer_8h.html#a406b0c0f39662fd6ef695c1d181d81daafdf7057ecd55509b744634131b873a1b", null ]
    ] ]
];