var class_customer_testimonials =
[
    [ "CustomerTestimonials", "class_customer_testimonials.html#a54f68fe2046aa9422c4d8a6476f09f0c", null ],
    [ "~CustomerTestimonials", "class_customer_testimonials.html#a0feb415aca8132459d393dbf151e267a", null ]
];