var classcustomer_purchase =
[
    [ "customerPurchase", "classcustomer_purchase.html#a62a28e52075c78a5d3d2eb3ae13fd8b8", null ],
    [ "~customerPurchase", "classcustomer_purchase.html#a304f6bb00baabf1e9fbd38cb58e1c8db", null ]
];