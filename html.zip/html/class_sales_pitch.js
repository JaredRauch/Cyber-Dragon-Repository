var class_sales_pitch =
[
    [ "SalesPitch", "class_sales_pitch.html#af152b41d8cdfc7f4c2010b64893a19c0", null ],
    [ "~SalesPitch", "class_sales_pitch.html#abe93abfa4f22c7add682de160ced4626", null ]
];