var class_ui___remove_window =
[
    [ "retranslateUi", "class_ui___remove_window.html#aded9d6e7b81ba90c66e20da79b01baec", null ],
    [ "setupUi", "class_ui___remove_window.html#ab191b7a7b5590d645aab2700d43fc9a6", null ],
    [ "Blank_Label", "class_ui___remove_window.html#a87ad5ea4633de92d84ce152382081ff9", null ],
    [ "centralwidget", "class_ui___remove_window.html#aa7c68b5b719e842cc69b021aa832dc8c", null ],
    [ "ConformBox", "class_ui___remove_window.html#a6564b9437e490829301a5f8f74914476", null ],
    [ "label", "class_ui___remove_window.html#a2521a8e93847998d0ee0d5329e8404be", null ],
    [ "menubar", "class_ui___remove_window.html#a38353033d0122d3482f3bcaa7c44b41b", null ],
    [ "NameLineEdit", "class_ui___remove_window.html#a79741d9e285d227cb08d967bd1f0f3fa", null ],
    [ "statusbar", "class_ui___remove_window.html#ae87e957ab41fcc3c64e645402684654e", null ]
];