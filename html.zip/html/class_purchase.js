var class_purchase =
[
    [ "Purchase", "class_purchase.html#a38aa12e4db7068596ad04e359917c05b", null ],
    [ "Purchase", "class_purchase.html#a783f7e6f5e4e7f6d2e9e20ec93c28f06", null ],
    [ "getCustomerName", "class_purchase.html#a7bbae4ae2400c94c67b3db8e6955c1aa", null ],
    [ "getEndDate", "class_purchase.html#a8fa13cd3424bff0a0589d9393415c19f", null ],
    [ "getOrderID", "class_purchase.html#a3ad1793d6736d0a11514025cf2da80b1", null ],
    [ "getPrice", "class_purchase.html#aa52f34b5ab4ee2ca409a0c6fa2b34dc0", null ],
    [ "getService", "class_purchase.html#a9f3556db528e7639ed3d1cd796209725", null ],
    [ "getStartDate", "class_purchase.html#a7a45b8ed26667c96b39b284791e6c2df", null ]
];