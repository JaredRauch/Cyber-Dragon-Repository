var class_ui__customer_purchase =
[
    [ "retranslateUi", "class_ui__customer_purchase.html#afc92200d483b775f2ca743165f5a6388", null ],
    [ "setupUi", "class_ui__customer_purchase.html#adb0b5ba634b694f3472453abd548bf70", null ],
    [ "comboBox", "class_ui__customer_purchase.html#a7d22fcda5741992f50a3e2b711725953", null ],
    [ "label", "class_ui__customer_purchase.html#aab2f8e6ced1d41044b5a3e094514c60c", null ],
    [ "tableWidget", "class_ui__customer_purchase.html#a11b7f0b7b7613b53ca761be41cf05ab3", null ],
    [ "verticalLayout", "class_ui__customer_purchase.html#a492a75ab04ef88c21830a8d921f110c4", null ]
];