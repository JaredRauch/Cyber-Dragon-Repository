var class_ui___customer_list =
[
    [ "retranslateUi", "class_ui___customer_list.html#a73a6b1c55136e708188fa1b64ed494a0", null ],
    [ "setupUi", "class_ui___customer_list.html#af561fdba2d2afb892c0eb6998b22f73e", null ],
    [ "AddButton", "class_ui___customer_list.html#af72bb4fa7d8fd28649167cfc74613800", null ],
    [ "centralWidget", "class_ui___customer_list.html#a19120619f7d300fabdc5627effa868fe", null ],
    [ "CustomerWidget", "class_ui___customer_list.html#aca1dc611be40c9ff103f69a5d146aaca", null ],
    [ "EditButton", "class_ui___customer_list.html#a4b1e4e820d3b1d097c8fbf9676be467d", null ],
    [ "horizontalLayout", "class_ui___customer_list.html#a609cdc516b26c74c03af076599458443", null ],
    [ "horizontalLayoutWidget", "class_ui___customer_list.html#adb9278e3926da6eed9811cf7aa0bf48e", null ],
    [ "InfoButton", "class_ui___customer_list.html#a70229d4b3a5474df6b2916f9d169f72f", null ],
    [ "mainToolBar", "class_ui___customer_list.html#a31e30875399a7c3ec9207a7db9ded89b", null ],
    [ "menuBar", "class_ui___customer_list.html#a9cefa13bce9fbe0cc7d32af78dd01524", null ],
    [ "pushButton", "class_ui___customer_list.html#af4790eceb9d1216583cadf020eebc336", null ],
    [ "RemoveButton", "class_ui___customer_list.html#a6ec0d20d28d828828a4d27562c0aa578", null ],
    [ "statusBar", "class_ui___customer_list.html#aadfbae8bd95d0594b28a441624746dd8", null ]
];