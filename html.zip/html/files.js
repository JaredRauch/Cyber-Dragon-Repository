var files =
[
    [ "addcustomerwindow.cpp", "addcustomerwindow_8cpp.html", null ],
    [ "addcustomerwindow.h", "addcustomerwindow_8h.html", [
      [ "AddCustomerWindow", "class_add_customer_window.html", "class_add_customer_window" ]
    ] ],
    [ "Address.cpp", "_address_8cpp.html", null ],
    [ "Address.h", "_address_8h.html", [
      [ "Address", "class_address.html", "class_address" ]
    ] ],
    [ "adminlogin.cpp", "adminlogin_8cpp.html", null ],
    [ "adminlogin.h", "adminlogin_8h.html", [
      [ "adminLogin", "classadmin_login.html", "classadmin_login" ]
    ] ],
    [ "conceptofoperations.cpp", "conceptofoperations_8cpp.html", null ],
    [ "conceptofoperations.h", "conceptofoperations_8h.html", [
      [ "ConceptOfOperations", "class_concept_of_operations.html", "class_concept_of_operations" ]
    ] ],
    [ "contactus.cpp", "contactus_8cpp.html", null ],
    [ "contactus.h", "contactus_8h.html", [
      [ "ContactUs", "class_contact_us.html", "class_contact_us" ]
    ] ],
    [ "Customer.cpp", "_customer_8cpp.html", null ],
    [ "Customer.h", "_customer_8h.html", "_customer_8h" ],
    [ "customerinfo.cpp", "customerinfo_8cpp.html", null ],
    [ "customerinfo.h", "customerinfo_8h.html", [
      [ "CustomerInfo", "class_customer_info.html", "class_customer_info" ]
    ] ],
    [ "customerlist.cpp", "customerlist_8cpp.html", null ],
    [ "customerlist.h", "customerlist_8h.html", [
      [ "CustomerList", "class_customer_list.html", "class_customer_list" ]
    ] ],
    [ "customerpurchase.cpp", "customerpurchase_8cpp.html", null ],
    [ "customerpurchase.h", "customerpurchase_8h.html", [
      [ "customerPurchase", "classcustomer_purchase.html", "classcustomer_purchase" ]
    ] ],
    [ "customertestimonials.cpp", "customertestimonials_8cpp.html", null ],
    [ "customertestimonials.h", "customertestimonials_8h.html", [
      [ "CustomerTestimonials", "class_customer_testimonials.html", "class_customer_testimonials" ]
    ] ],
    [ "Database.cpp", "_database_8cpp.html", null ],
    [ "Database.h", "_database_8h.html", [
      [ "InvalidLoginException", "class_invalid_login_exception.html", "class_invalid_login_exception" ],
      [ "KeyCollisionException", "class_key_collision_exception.html", "class_key_collision_exception" ],
      [ "Database", "class_database.html", "class_database" ]
    ] ],
    [ "Date.cpp", "_date_8cpp.html", null ],
    [ "Date.h", "_date_8h.html", [
      [ "Date", "class_date.html", "class_date" ]
    ] ],
    [ "dialog.cpp", "dialog_8cpp.html", null ],
    [ "dialog.h", "dialog_8h.html", [
      [ "Dialog", "class_dialog.html", "class_dialog" ]
    ] ],
    [ "errorwindow.cpp", "errorwindow_8cpp.html", null ],
    [ "errorwindow.h", "errorwindow_8h.html", [
      [ "ErrorWindow", "class_error_window.html", "class_error_window" ]
    ] ],
    [ "guarantee.cpp", "guarantee_8cpp.html", null ],
    [ "guarantee.h", "guarantee_8h.html", [
      [ "Guarantee", "class_guarantee.html", "class_guarantee" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "maintenanceplan.cpp", "maintenanceplan_8cpp.html", null ],
    [ "maintenanceplan.h", "maintenanceplan_8h.html", [
      [ "MaintenancePlan", "class_maintenance_plan.html", "class_maintenance_plan" ]
    ] ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "orderproduct.cpp", "orderproduct_8cpp.html", null ],
    [ "orderproduct.h", "orderproduct_8h.html", [
      [ "OrderProduct", "class_order_product.html", "class_order_product" ]
    ] ],
    [ "programinstructions.cpp", "programinstructions_8cpp.html", null ],
    [ "programinstructions.h", "programinstructions_8h.html", [
      [ "ProgramInstructions", "class_program_instructions.html", "class_program_instructions" ]
    ] ],
    [ "Purchase.cpp", "_purchase_8cpp.html", null ],
    [ "Purchase.h", "_purchase_8h.html", "_purchase_8h" ],
    [ "removewindow.cpp", "removewindow_8cpp.html", null ],
    [ "removewindow.h", "removewindow_8h.html", [
      [ "RemoveWindow", "class_remove_window.html", "class_remove_window" ]
    ] ],
    [ "requestpamphlet.cpp", "requestpamphlet_8cpp.html", null ],
    [ "requestpamphlet.h", "requestpamphlet_8h.html", [
      [ "RequestPamphlet", "class_request_pamphlet.html", "class_request_pamphlet" ]
    ] ],
    [ "salespitch.cpp", "salespitch_8cpp.html", null ],
    [ "salespitch.h", "salespitch_8h.html", [
      [ "SalesPitch", "class_sales_pitch.html", "class_sales_pitch" ]
    ] ],
    [ "serviceoptions.cpp", "serviceoptions_8cpp.html", null ],
    [ "serviceoptions.h", "serviceoptions_8h.html", [
      [ "ServiceOptions", "class_service_options.html", "class_service_options" ]
    ] ],
    [ "sha1.cpp", "sha1_8cpp.html", null ],
    [ "sha1.h", "sha1_8h.html", [
      [ "SHA1", "class_s_h_a1.html", "class_s_h_a1" ]
    ] ],
    [ "sqlite3.c", "sqlite3_8c.html", "sqlite3_8c" ],
    [ "sqlite3.h", "sqlite3_8h.html", "sqlite3_8h" ],
    [ "Testimonial.cpp", "_testimonial_8cpp.html", null ],
    [ "Testimonial.h", "_testimonial_8h.html", [
      [ "Testimonial", "class_testimonial.html", "class_testimonial" ]
    ] ],
    [ "ui_addcustomerwindow.h", "ui__addcustomerwindow_8h.html", [
      [ "Ui_AddCustomerWindow", "class_ui___add_customer_window.html", "class_ui___add_customer_window" ],
      [ "AddCustomerWindow", "class_ui_1_1_add_customer_window.html", null ]
    ] ],
    [ "ui_adminlogin.h", "ui__adminlogin_8h.html", [
      [ "Ui_adminLogin", "class_ui__admin_login.html", "class_ui__admin_login" ],
      [ "adminLogin", "class_ui_1_1admin_login.html", null ]
    ] ],
    [ "ui_contactus.h", "ui__contactus_8h.html", [
      [ "Ui_ContactUs", "class_ui___contact_us.html", "class_ui___contact_us" ],
      [ "ContactUs", "class_ui_1_1_contact_us.html", null ]
    ] ],
    [ "ui_customerinfo.h", "ui__customerinfo_8h.html", [
      [ "Ui_CustomerInfo", "class_ui___customer_info.html", "class_ui___customer_info" ],
      [ "CustomerInfo", "class_ui_1_1_customer_info.html", null ]
    ] ],
    [ "ui_customerlist.h", "ui__customerlist_8h.html", [
      [ "Ui_CustomerList", "class_ui___customer_list.html", "class_ui___customer_list" ],
      [ "CustomerList", "class_ui_1_1_customer_list.html", null ]
    ] ],
    [ "ui_customerpurchase.h", "ui__customerpurchase_8h.html", [
      [ "Ui_customerPurchase", "class_ui__customer_purchase.html", "class_ui__customer_purchase" ],
      [ "customerPurchase", "class_ui_1_1customer_purchase.html", null ]
    ] ],
    [ "ui_customertestimonials.h", "ui__customertestimonials_8h.html", [
      [ "Ui_CustomerTestimonials", "class_ui___customer_testimonials.html", "class_ui___customer_testimonials" ],
      [ "CustomerTestimonials", "class_ui_1_1_customer_testimonials.html", null ]
    ] ],
    [ "ui_dialog.h", "ui__dialog_8h.html", [
      [ "Ui_Dialog", "class_ui___dialog.html", "class_ui___dialog" ],
      [ "Dialog", "class_ui_1_1_dialog.html", null ]
    ] ],
    [ "ui_errorwindow.h", "ui__errorwindow_8h.html", [
      [ "Ui_ErrorWindow", "class_ui___error_window.html", "class_ui___error_window" ],
      [ "ErrorWindow", "class_ui_1_1_error_window.html", null ]
    ] ],
    [ "ui_maintenanceplan.h", "ui__maintenanceplan_8h.html", [
      [ "Ui_MaintenancePlan", "class_ui___maintenance_plan.html", "class_ui___maintenance_plan" ],
      [ "MaintenancePlan", "class_ui_1_1_maintenance_plan.html", null ]
    ] ],
    [ "ui_mainwindow.h", "ui__mainwindow_8h.html", [
      [ "Ui_MainWindow", "class_ui___main_window.html", "class_ui___main_window" ],
      [ "MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "ui_orderproduct.h", "ui__orderproduct_8h.html", [
      [ "Ui_OrderProduct", "class_ui___order_product.html", "class_ui___order_product" ],
      [ "OrderProduct", "class_ui_1_1_order_product.html", null ]
    ] ],
    [ "ui_programinstructions.h", "ui__programinstructions_8h.html", [
      [ "Ui_ProgramInstructions", "class_ui___program_instructions.html", "class_ui___program_instructions" ],
      [ "ProgramInstructions", "class_ui_1_1_program_instructions.html", null ]
    ] ],
    [ "ui_removewindow.h", "ui__removewindow_8h.html", [
      [ "Ui_RemoveWindow", "class_ui___remove_window.html", "class_ui___remove_window" ],
      [ "RemoveWindow", "class_ui_1_1_remove_window.html", null ]
    ] ],
    [ "ui_requestpamphlet.h", "ui__requestpamphlet_8h.html", [
      [ "Ui_RequestPamphlet", "class_ui___request_pamphlet.html", "class_ui___request_pamphlet" ],
      [ "RequestPamphlet", "class_ui_1_1_request_pamphlet.html", null ]
    ] ]
];