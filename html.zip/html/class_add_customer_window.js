var class_add_customer_window =
[
    [ "AddCustomerWindow", "class_add_customer_window.html#a1a657070fdde3f7462c117335acffb1b", null ],
    [ "~AddCustomerWindow", "class_add_customer_window.html#a8ea6d48e3dc87c4a80600d88e16ef62d", null ],
    [ "SetCustomer", "class_add_customer_window.html#acccb298777e4e22980f326c443e5b4f0", null ]
];