var NAVTREE =
[
  [ "cyberDragon", "index.html", [
    [ "Cyber-Dragon-Repository", "md_README.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_address_8cpp.html",
"class_ui___customer_testimonials.html",
"globals_defs_e.html",
"sqlite3_8c.html#a0d9118aefe1a5c763907054927f38561",
"sqlite3_8c.html#a211fbdef03e8a0c872bc6e27f258f784",
"sqlite3_8c.html#a38d14ac56c4fae61d7ae4b27fdc2a937",
"sqlite3_8c.html#a4dde2e4087eda945511b05d667050740",
"sqlite3_8c.html#a5f876209b4343549fc9224cd11c70928",
"sqlite3_8c.html#a76057aff58e5cef58bcdb0486a503a39",
"sqlite3_8c.html#a8b123acd3401827e0d5bd75e7a46e5c0",
"sqlite3_8c.html#a9f0d99e4d6f09f062fe7639e563d1de3",
"sqlite3_8c.html#ab2f906b19e77e57755c00f7cae712f14",
"sqlite3_8c.html#aca0580ef6b926d70e1aa6ca04a8efd8b",
"sqlite3_8c.html#aded6c0832b619d1a8533d847fc55580f",
"sqlite3_8c.html#af415e0fc4b0e6cceb9d2be99e019392f",
"sqlite3_8h.html#a28fb207fd72aa6cde4c74da94b01ac4e",
"sqlite3_8h.html#a90c6b4da52f944b15bcbfb55c65035ed",
"sqlite3_8h.html#aff64e159370db8ebd4f767b43ed74959",
"struct_file_point.html",
"struct_p_group.html#ac7cdffac1c20d260e8230dba4ab05cea",
"struct_schema.html#ad51ed96351701cfe8d9e871722827c11",
"struct_unpacked_record.html#a2c5062735cdbc5039679d255cc900668",
"struct_where_info.html#a338ac73b84c81db455ad7db56b5e4a06",
"structsqlite3__api__routines.html#a04499bf64d666eb00fb19ae01cdbb8b1",
"structsqlite3__index__info_1_1sqlite3__index__constraint.html",
"union_mem_1_1_mem_value.html#ac783c60cc4b1c0893931c997aa04ded6"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';