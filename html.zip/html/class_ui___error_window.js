var class_ui___error_window =
[
    [ "retranslateUi", "class_ui___error_window.html#a15b9f964a3a4129d0453864a7b6cefb5", null ],
    [ "setupUi", "class_ui___error_window.html#aff79a40b5501d7aed0338d69fa5ea11b", null ],
    [ "centralwidget", "class_ui___error_window.html#a5a11cd3efa5a3423552d8053dded9d65", null ],
    [ "label", "class_ui___error_window.html#a6d53352fb099ea9298033f03bb1905f9", null ],
    [ "menubar", "class_ui___error_window.html#ac1b97225206658c9b463aa41706f1a8e", null ],
    [ "pushButton", "class_ui___error_window.html#a9ca01007d79bd7f2e2d3e930595d8192", null ],
    [ "statusbar", "class_ui___error_window.html#aaffe43c84d27514a6ed02bdcc8b56d7e", null ]
];