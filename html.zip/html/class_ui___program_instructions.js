var class_ui___program_instructions =
[
    [ "retranslateUi", "class_ui___program_instructions.html#a621c2d1e16b8b7f16797f537c6685803", null ],
    [ "setupUi", "class_ui___program_instructions.html#a5b6a48afc77e11507b4f75474c4d230e", null ],
    [ "label", "class_ui___program_instructions.html#aa3ac12dc684eb12407d68176f693d764", null ],
    [ "textBrowser", "class_ui___program_instructions.html#a5772cda42c7277e52fc09e8c0f781800", null ],
    [ "verticalLayout", "class_ui___program_instructions.html#ae939b1b51f3d1e4c050fd135850f54f1", null ]
];