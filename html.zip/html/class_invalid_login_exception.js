var class_invalid_login_exception =
[
    [ "InvalidLoginException", "class_invalid_login_exception.html#a0dd92ebdf187ca85f97a7bcc31130027", null ],
    [ "~InvalidLoginException", "class_invalid_login_exception.html#ac1321488e7be504bcca3be6ffb334715", null ],
    [ "what", "class_invalid_login_exception.html#af07e01f3bf342309ce7357343608b8ac", null ]
];