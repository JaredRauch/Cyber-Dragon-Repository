var class_testimonial =
[
    [ "Testimonial", "class_testimonial.html#a446e9d9df1e22f3d77f4c08e3f982d79", null ],
    [ "getCustomer", "class_testimonial.html#a01efcb966d221c25ffeeec2a4afea4de", null ],
    [ "getText", "class_testimonial.html#a61d4f7bf6043e4f5bc2bd9880101ec6f", null ],
    [ "setText", "class_testimonial.html#a23ff44003c73fe204e4a9031dbb3bfe2", null ]
];