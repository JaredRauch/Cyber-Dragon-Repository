var class_concept_of_operations =
[
    [ "ConceptOfOperations", "class_concept_of_operations.html#af6284d79a1ec15e2a59cb15a9b366496", null ],
    [ "~ConceptOfOperations", "class_concept_of_operations.html#aeaac1fc4265f7df8e9259cf0ba1264e8", null ]
];