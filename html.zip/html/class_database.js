var class_database =
[
    [ "Database", "class_database.html#a1efdabff37c6e25b65e7133c1b519091", null ],
    [ "~Database", "class_database.html#a84d399a2ad58d69daab9b05330e1316d", null ],
    [ "AddCustomer", "class_database.html#a06caf3444e35b7535fc0784d55e21b2c", null ],
    [ "loginAsAdmin", "class_database.html#a66b2b58792dbac8c05b95235636cfbfc", null ],
    [ "loginAsCustomer", "class_database.html#ae1635df0a5aef806cdccc881a52eb96e", null ],
    [ "registerAdmin", "class_database.html#af7530e5cfe5cc569ca18d52177b07499", null ],
    [ "registerCustomer", "class_database.html#a0e2d142fdd8b24ee8ddcbc84d37bc6bf", null ]
];