var searchData=
[
  ['namecontext',['NameContext',['../struct_name_context.html',1,'']]]
];
