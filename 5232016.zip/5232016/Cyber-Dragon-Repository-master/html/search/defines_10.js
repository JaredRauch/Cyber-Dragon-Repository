var searchData=
[
  ['read_5flock',['READ_LOCK',['../sqlite3_8c.html#a5b9b681ff830ce05cc03c3ad38019817',1,'sqlite3.c']]],
  ['read_5futf16be',['READ_UTF16BE',['../sqlite3_8c.html#a971dc45fc54dd1c74f07a90edb1e8aad',1,'sqlite3.c']]],
  ['read_5futf16le',['READ_UTF16LE',['../sqlite3_8c.html#ad8a25758164d5dc3c72a8d72c0696d68',1,'sqlite3.c']]],
  ['read_5futf8',['READ_UTF8',['../sqlite3_8c.html#a4ce92284a5209e13ccf68faaa28a4e4b',1,'sqlite3.c']]],
  ['readmark_5fnot_5fused',['READMARK_NOT_USED',['../sqlite3_8c.html#a4429235090bcad8320b8805ef5c72b58',1,'sqlite3.c']]],
  ['register_5ftrace',['REGISTER_TRACE',['../sqlite3_8c.html#a5b53a62063ec152ad85f08c5b6e36949',1,'sqlite3.c']]],
  ['reserved_5fbyte',['RESERVED_BYTE',['../sqlite3_8c.html#a8ac9fa3da7151dc5ffd9fbf0563a9417',1,'sqlite3.c']]],
  ['reserved_5flock',['RESERVED_LOCK',['../sqlite3_8c.html#a4fec7ca081b31fb9e121208e2b57fe3f',1,'sqlite3.c']]],
  ['restorecursorposition',['restoreCursorPosition',['../sqlite3_8c.html#a291b3e39e6c5a36b58cdc5a60b8c72bd',1,'sqlite3.c']]],
  ['round8',['ROUND8',['../sqlite3_8c.html#aab26b71a52bee00471c8195453b56e4b',1,'sqlite3.c']]],
  ['rounddown8',['ROUNDDOWN8',['../sqlite3_8c.html#abd2d106601a2b1a2c5a960f32deb7be6',1,'sqlite3.c']]],
  ['rowset_5fallocation_5fsize',['ROWSET_ALLOCATION_SIZE',['../sqlite3_8c.html#a384d7734bbb2f6278e853713f1f01920',1,'sqlite3.c']]],
  ['rowset_5fentry_5fper_5fchunk',['ROWSET_ENTRY_PER_CHUNK',['../sqlite3_8c.html#a351eaade204118dea320a04b9a584b10',1,'sqlite3.c']]],
  ['rowset_5fnext',['ROWSET_NEXT',['../sqlite3_8c.html#a7d910eb4dd04c2f2cceb61a2581c83e1',1,'sqlite3.c']]],
  ['rowset_5fsorted',['ROWSET_SORTED',['../sqlite3_8c.html#a192f61c92b89c43dd1744e0e7eed406c',1,'sqlite3.c']]]
];
