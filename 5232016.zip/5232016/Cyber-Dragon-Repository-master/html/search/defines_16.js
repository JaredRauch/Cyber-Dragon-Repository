var searchData=
[
  ['xn_5fexpr',['XN_EXPR',['../sqlite3_8c.html#a62fae085d08bcae54d0d024a2bab1479',1,'sqlite3.c']]],
  ['xn_5frowid',['XN_ROWID',['../sqlite3_8c.html#a7c09becde7eacc75f3b838d0899c414f',1,'sqlite3.c']]]
];
