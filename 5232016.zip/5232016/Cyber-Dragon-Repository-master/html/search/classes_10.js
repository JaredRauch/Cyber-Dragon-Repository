var searchData=
[
  ['removewindow',['RemoveWindow',['../class_ui_1_1_remove_window.html',1,'Ui']]],
  ['removewindow',['RemoveWindow',['../class_remove_window.html',1,'']]],
  ['requestpamphlet',['RequestPamphlet',['../class_request_pamphlet.html',1,'']]],
  ['requestpamphlet',['RequestPamphlet',['../class_ui_1_1_request_pamphlet.html',1,'Ui']]],
  ['reusablespace',['ReusableSpace',['../struct_reusable_space.html',1,'']]],
  ['rowset',['RowSet',['../struct_row_set.html',1,'']]],
  ['rowsetchunk',['RowSetChunk',['../struct_row_set_chunk.html',1,'']]],
  ['rowsetentry',['RowSetEntry',['../struct_row_set_entry.html',1,'']]]
];
